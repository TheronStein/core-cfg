local wezterm = require("wezterm")
local backdrops = require("utils.backdrops")
local act = wezterm.action
local workspace_manager = require("modules.workspace_manager")
local bookmarks = require("modules.bookmarks")

local function is_vim(pane)
	return pane:get_user_vars().IS_NVIM == "true"
end

local keys = {
	-- Workspace management
	--

	{ key = "LeftAlt", mods = "NONE", action = "ActivateCopyMode" },
	{ key = "RightAlt", mods = "NONE", action = "ActivateCopyMode" },
	{ key = "`", mods = "LEADER", action = "ActivateCopyMode" },
	-- { key = "F1", mods = "NONE", action = act.ShowLauncherArgs({ flags = "FUZZY|WORKSPACES" }) },
	{
		key = "F2",
		mods = "LEADER",
		action = act.PromptInputLine({
			description = "Enter new name for tab",
			initial_value = "",
			action = wezterm.action_callback(function(window, pane, line)
				-- line will be `nil` if they hit escape without entering anything
				-- An empty string if they just hit enter
				-- Or the actual line of text they wrote
				if line then
					window:active_tab():set_title(line)
				end
			end),
		}),
	},

	-- Move current pane to new tab
	-- { key = "!", mods = "LEADER|SHIFT", action = act.MovePane("NewTab") },
	-- Move current pane to new window
	-- { key = "@", mods = "LEADER|SHIFT", action = act.MovePane("NewWindow") },
	-- Pane picker - SHOWS ALL PANES ACROSS ALL TABS
	--
	{ key = "q", mods = "LEADER", action = act.PaneSelect },
	-- Pane picker with arrows to swap positions
	--
	{ key = "Q", mods = "LEADER|SHIFT", action = act.PaneSelect({ mode = "SwapWithActive" }) },
	-- Rotate panes in current tab
	{ key = "e", mods = "LEADER|CTRL", action = act.RotatePanes("Clockwise") },
	{ key = "q", mods = "LEADER|CTRL", action = act.RotatePanes("CounterClockwise") },

	{
		key = "n",
		mods = "LEADER",
		action = act.PromptInputLine({
			description = "Enter new workspace name:",
			action = wezterm.action_callback(function(window, pane, line)
				if line then
					window:perform_action(act.SwitchToWorkspace({ name = line }), pane)
				end
			end),
		}),
	},
	{
		key = "b",
		mods = "LEADER",
		action = wezterm.action.InputSelector({
			title = "Bookmark Actions",
			choices = {
				{ label = "Jump to bookmark", id = "jump" },
				{ label = "Add bookmark", id = "add" },
				{ label = "Remove bookmark", id = "remove" },
				{ label = "List bookmarks", id = "list" },
			},
			action = wezterm.action_callback(function(window, pane, id, label)
				if id == "jump" then
					bookmarks.jump_to_bookmark(window, pane)
				elseif id == "add" then
					bookmarks.add_bookmark(window, pane)
				elseif id == "remove" then
					bookmarks.remove_bookmark(window, pane)
				elseif id == "list" then
					bookmarks.list_bookmarks(window, pane)
				end
			end),
		}),
	},
	{
		key = "S",
		mods = "LEADER|SHIFT",
		action = wezterm.action.PromptInputLine({
			description = "Save current layout as workspace:",
			action = wezterm.action_callback(function(window, pane, line)
				if line and line ~= "" then
					local definition = workspace_manager.capture_current(window, line)
					if definition then
						workspace_manager.save_workspace(line, definition)
						window:toast_notification("WezTerm", "Saved workspace: " .. line, nil, 2000)
					end
				end
			end),
		}),
	},

	-- Load workspace
	{
		key = "L",
		mods = "LEADER|SHIFT",
		action = wezterm.action_callback(function(window, pane)
			local workspaces = workspace_manager.list_workspaces()

			if #workspaces == 0 then
				window:toast_notification("WezTerm", "No saved workspaces", nil, 2000)
				return
			end

			local choices = {}
			for _, name in ipairs(workspaces) do
				table.insert(choices, { label = name })
			end

			window:perform_action(
				wezterm.action.InputSelector({
					title = "Load Workspace",
					choices = choices,
					fuzzy = true,
					action = wezterm.action_callback(function(win, p, id, label)
						if label then
							workspace_manager.ensure_workspace(label)
							win:perform_action(wezterm.action.SwitchToWorkspace({ name = label }), p)
						end
					end),
				}),
				pane
			)
		end),
	},

	-- Delete workspace
	{
		key = "D",
		mods = "LEADER|SHIFT",
		action = wezterm.action_callback(function(window, pane)
			local workspaces = workspace_manager.list_workspaces()

			if #workspaces == 0 then
				window:toast_notification("WezTerm", "No saved workspaces", nil, 2000)
				return
			end

			local choices = {}
			for _, name in ipairs(workspaces) do
				table.insert(choices, { label = name })
			end

			window:perform_action(
				wezterm.action.InputSelector({
					title = "Delete Workspace",
					choices = choices,
					fuzzy = true,
					action = wezterm.action_callback(function(win, p, id, label)
						if label then
							workspace_manager.delete_workspace(label)
							win:toast_notification("WezTerm", "Deleted: " .. label, nil, 2000)
						end
					end),
				}),
				pane
			)
		end),
	},
	-- CTRL|SHFT BINDS

	-- copy/paste
	{ key = "c", mods = "CTRL|SHIFT", action = act.CopyTo("Clipboard") },
	{ key = "v", mods = "CTRL|SHIFT", action = act.PasteFrom("Clipboard") },
	-- { key = 'c',          mods = 'CTRL|SHIFT',  action = act.CopyTo('Clipboard') },

	-- Tab management
	{ key = "c", mods = "LEADER", action = act.SpawnTab("CurrentPaneDomain") },

	{ key = "r", mods = "LEADER|CTRL", action = act.ReloadConfiguration },

	{
		key = "R",
		mods = "SUPER|ALT",
		action = wezterm.action_callback(function(window, _pane)
			backdrops:random(window)
		end),
	},
	{
		key = "Q",
		mods = "SUPER|ALT",
		action = wezterm.action_callback(function(window, _pane)
			backdrops:cycle_back(window)
		end),
	},
	{
		key = "E",
		mods = "SUPER|ALT",
		action = wezterm.action_callback(function(window, _pane)
			backdrops:cycle_forward(window)
		end),
	},
	{
		key = "S",
		mods = "SUPER|ALT",
		action = act.InputSelector({
			title = "InputSelector: Select Background",
			choices = backdrops:choices(),
			fuzzy = true,
			fuzzy_description = "Select Background: ",
			action = wezterm.action_callback(function(window, _pane, idx)
				if not idx then
					return
				end
				---@diagnostic disable-next-line: param-type-mismatch
				backdrops:set_img(window, tonumber(idx))
			end),
		}),
	},

	{
		key = "W",
		mods = "LEADER|CTRL",
		action = act.PromptInputLine({
			description = wezterm.format({
				{ Attribute = { Intensity = "Bold" } },
				{ Foreground = { AnsiColor = "Fuchsia" } },
				{ Text = "Enter name for new workspace" },
			}),
			action = wezterm.action_callback(function(window, pane, line)
				-- line will be `nil` if they hit escape without entering anything
				-- An empty string if they just hit enter
				-- Or the actual line of text they wrote
				if line then
					window:perform_action(
						act.SwitchToWorkspace({
							name = line,
						}),
						pane
					)
				end
			end),
		}),
	},

	{ key = "q", mods = "LEADER", action = act.ActivateTabRelative(1) },
	{ key = "e", mods = "LEADER", action = act.ActivateTabRelative(-1) },
	{ key = "q", mods = "SUPER|SHIFT", action = act.MoveTabRelative(-1) },
	{ key = "e", mods = "SUPER|SHIFT", action = act.MoveTabRelative(-1) },
	{ key = "j", mods = "LEADER", action = act.ActivatePaneDirection("Left") },
	{ key = "l", mods = "LEADER", action = act.ActivatePaneDirection("Right") },
	{ key = "i", mods = "LEADER", action = act.ActivatePaneDirection("Up") },
	{ key = "k", mods = "LEADER", action = act.ActivatePaneDirection("Down") },
	{ key = "a", mods = "LEADER", action = act.ActivatePaneDirection("Left") },
	{ key = "d", mods = "LEADER", action = act.ActivatePaneDirection("Right") },
	{ key = "w", mods = "LEADER", action = act.ActivatePaneDirection("Up") },
	{ key = "s", mods = "LEADER", action = act.ActivatePaneDirection("Down") },
	{ key = "x", mods = "LEADER", action = act.CloseCurrentPane({ confirm = false }) },

	{
		key = "F5",
		mods = "LEADER",
		action = wezterm.action_callback(function(window, pane)
			local schemes = wezterm.get_builtin_color_schemes()
			local choices = {}

			for key, _ in pairs(schemes) do
				table.insert(choices, { label = tostring(key) })
			end

			table.sort(choices, function(c1, c2)
				return c1.label < c2.label
			end)

			window:perform_action(
				act.InputSelector({
					title = "Pick a Theme",
					choices = choices,
					fuzzy = true,
					action = wezterm.action_callback(function(inner_window, inner_pane, id, label)
						if label then
							inner_window:set_config_overrides({ color_scheme = label })
						end
					end),
				}),
				pane
			)
		end),
	},

	{ key = "UpArrow", mods = "SUPER", action = act.ScrollByPage(-1) },
	{ key = "DownArrow", mods = "SUPER", action = act.ScrollByPage(1) },

	-- { key = "c", mods = "LEADER|CTRL", action = wezterm.action.ActivateCopyMode },
	-- { key = "l", mods = "LEADER|CTRL", action = wezterm.action.ShowDebugOverlay },
	-- { key = "p", mods = "LEADER|CTRL", action = wezterm.action.ActivateCommandPalette },

	-- window: zoom window
	{
		key = "-",
		mods = "SUPER",
		action = wezterm.action_callback(function(window, _pane)
			local dimensions = window:get_dimensions()
			if dimensions.is_full_screen then
				return
			end
			local new_width = dimensions.pixel_width - 50
			local new_height = dimensions.pixel_height - 50
			window:set_inner_size(new_width, new_height)
		end),
	},
	{
		key = "=",
		mods = "SUPER",
		action = wezterm.action_callback(function(window, _pane)
			local dimensions = window:get_dimensions()
			if dimensions.is_full_screen then
				return
			end
			local new_width = dimensions.pixel_width + 50
			local new_height = dimensions.pixel_height + 50
			window:set_inner_size(new_width, new_height)
		end),
	},

	{ key = "t", mods = "LEADER|CTRL", action = act.EmitEvent("tabs.manual-update-tab-title") },
	{ key = "T", mods = "LEADER|CTRL|SHIFT", action = act.EmitEvent("tabs.reset-tab-title") },

	{
		key = "d",
		mods = "LEADER",
		action = act.SplitVertical({ domain = "CurrentPaneDomain" }),
	},
	{
		key = "v",
		mods = "LEADER",
		action = act.SplitHorizontal({ domain = "CurrentPaneDomain" }),
	},

	{ key = "PageUp", mods = "SHIFT", action = act.ScrollByPage(-1) },
	{ key = "PageDown", mods = "SHIFT", action = act.ScrollByPage(1) },

	-- panes: navigation
	{ key = "k", mods = "SUPER", action = act.ActivatePaneDirection("Up") },
	{ key = "j", mods = "SUPER", action = act.ActivatePaneDirection("Down") },
	{ key = "h", mods = "SUPER", action = act.ActivatePaneDirection("Left") },
	{ key = "l", mods = "SUPER", action = act.ActivatePaneDirection("Right") },
	-- {
	--    key = 'p',
	--    mods = mod.SUPER_REV,
	--    action = act.PaneSelect({ alphabet = '1234567890', mode = 'SwapWithActiveKeepFocus' }),
	-- },

	-- keytables
	{
		key = "f",
		mods = "LEADER|SHIFT",
		action = act.ActivateKeyTable({
			name = "resize_font",
			one_shot = false,
			timemout_milliseconds = 1000,
		}),
	},
	{
		key = "r",
		mods = "LEADER|SHIFT",
		action = act.ActivateKeyTable({
			name = "resize_pane",
			one_shot = false,
			timemout_milliseconds = 1000,
		}),
	},
	{
		key = "Tab",
		mods = "LEADER|SHIFT",
		action = act.ActivateKeyTable({
			name = "nav_panes",
			one_shot = false,
			timemout_milliseconds = 1000,
		}),
	},
}

-- stylua: ignore
local key_tables = {
   resize_font = {
      { key = 'w',      action = act.IncreaseFontSize },
      { key = 's',      action = act.DecreaseFontSize },
      { key = 'i',      action = act.IncreaseFontSize },
      { key = 'k',      action = act.DecreaseFontSize },
      { key = 'r',      action = act.ResetFontSize },
      { key = 'Escape', action = 'PopKeyTable' },
	  { key = "C", mods = "CTRL", action = "PopKeyTable" },
      { key = 'q',      action = 'PopKeyTable' },
   },
	nav_panes = {
		-- Pane navigation
		{ key = "r", action = act.RotatePanes("Clockwise") },
		{ key = "R", action = act.RotatePanes("CounterClockwise") },
        { key = "a", action = act.ActivatePaneDirection("Left") },
		{ key = "d", action = act.ActivatePaneDirection("Right") },
		{ key = "w", action = act.ActivatePaneDirection("Up") },
		{ key = "s", action = act.ActivatePaneDirection("Down") },
		{ key = "j", action = act.ActivatePaneDirection("Left") },
		{ key = "l", action = act.ActivatePaneDirection("Right") },
		{ key = "i", action = act.ActivatePaneDirection("Up") },
		{ key = "k", action = act.ActivatePaneDirection("Down") },
		{ key = "Escape", action = "PopKeyTable" },
		{ key = "C", mods = "CTRL", action = "PopKeyTable" },
        { key = 'q',      action = 'PopKeyTable' },
  },
  resize_pane = {
        { key = "a", action = act.ActivatePaneDirection("Left") },
		{ key = "d", action = act.ActivatePaneDirection("Right") },
		{ key = "w", action = act.ActivatePaneDirection("Up") },
		{ key = "s", action = act.ActivatePaneDirection("Down") },
    { key = "j", action = act.AdjustPaneSize({ "Left", 5 }) },
	{ key = "l", action = act.AdjustPaneSize({ "Right", 5 }) },
	{ key = "i", action = act.AdjustPaneSize({ "Up", 5 }) },
	{ key = "k", action = act.AdjustPaneSize({ "Down", 5 }) },	
	{ key = "j", mods = "CTRL", action = act.AdjustPaneSize({ "Left", 10 }) },
	{ key = "l", mods = "CTRL", action = act.AdjustPaneSize({ "Right", 10 }) },
	{ key = "i", mods = "CTRL", action = act.AdjustPaneSize({ "Up", 10 }) },
	{ key = "k", mods = "CTRL", action = act.AdjustPaneSize({ "Down", 10 }) },
    { key = "Escape", action = "PopKeyTable" },
	{ key = "C", mods = "CTRL", action = "PopKeyTable" },
    { key = 'q',      action = 'PopKeyTable' },
  },
}

local mouse_bindings = {
	-- Ctrl-click will open the link under the mouse cursor
	{
		event = { Up = { streak = 1, button = "Left" } },
		mods = "CTRL",
		action = act.OpenLinkAtMouseCursor,
	},
}

-- #TODO, implement background
--
--   -- background controls --
-- {
--    key = [[/]],
--    mods = mod.SUPER,
--    action = wezterm.action_callback(function(window, _pane)
--       backdrops:random(window)
--    end),
-- },
-- {
--    key = [[,]],
--    mods = mod.SUPER,
--    action = wezterm.action_callback(function(window, _pane)
--       backdrops:cycle_back(window)
--    end),
-- },
-- {
--    key = [[.]],
--    mods = mod.SUPER,
--    action = wezterm.action_callback(function(window, _pane)
--       backdrops:cycle_forward(window)
--    end),
-- },
-- {
--    key = [[/]],
--    mods = mod.SUPER_REV,
--    action = act.InputSelector({
--       title = 'InputSelector: Select Background',
--       choices = backdrops:choices(),
--       fuzzy = true,
--       fuzzy_description = 'Select Background: ',
--       action = wezterm.action_callback(function(window, _pane, idx)
--          if not idx then
--             return
--          end
--          ---@diagnostic disable-next-line: param-type-mismatch
--          backdrops:set_img(window, tonumber(idx))
--       end),
--    }),
-- }

return {
	-- disable_default_mouse_bindings = true,
	leader = { key = "Space", mods = "SUPER", timeout_milliseconds = 1000 },
	keys = keys,
	key_tables = key_tables,
	mouse_bindings = mouse_bindings,
}

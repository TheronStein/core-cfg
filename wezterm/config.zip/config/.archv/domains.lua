local wezterm = require("wezterm")

-- Use the default runtime directory
local runtime_dir = os.getenv("XDG_RUNTIME_DIR") or os.getenv("HOME") .. "/.local/share/wezterm"

local M = {}

-- Scan for available mux domain sockets
local function discover_mux_domains()
	local domains = {}

	-- Try to read the runtime directory
	local success, entries = pcall(function()
		return wezterm.read_dir(runtime_dir)
	end)

	if success and entries then
		for _, entry in ipairs(entries) do
			local filename = entry:match("([^/]+)$")

			-- Look for .sock files, excluding the default "sock" file
			if filename and filename:match("%.sock$") and filename ~= "sock" then
				local domain_name = filename:match("^(.+)%.sock$")

				if domain_name then
					wezterm.log_info("Discovered mux domain: " .. domain_name)
					table.insert(domains, {
						name = domain_name,
						socket_path = runtime_dir .. "/" .. filename,
						no_serve_automatically = true,
					})
				end
			end
		end
	else
		wezterm.log_warn("Could not read runtime directory: " .. runtime_dir)
	end

	-- Sort domains alphabetically
	table.sort(domains, function(a, b)
		return a.name < b.name
	end)

	return domains
end

-- Discover all available domains
local unix_domains = discover_mux_domains()

-- Determine default domain
local default_domain = nil
if #unix_domains > 0 then
	-- Try to use arch-asusfx as default if it exists
	for _, domain in ipairs(unix_domains) do
		if domain.name == "arch-asusfx" then
			default_domain = "arch-asusfx"
			break
		end
	end

	-- Otherwise use the first domain
	if not default_domain then
		default_domain = unix_domains[1].name
	end

	wezterm.log_info("Default domain set to: " .. default_domain)
	wezterm.log_info("Total mux domains discovered: " .. #unix_domains)
else
	wezterm.log_warn("No mux domains discovered - local mode only")
end

-- Return configuration options
M = {
	unix_domains = unix_domains,
	default_domain = default_domain,
	ssh_domains = {},
	exec_domains = {},
}

-- Only set default_gui_startup_args if we have a default domain
if default_domain then
	M.default_gui_startup_args = { "connect", default_domain }
end

return M

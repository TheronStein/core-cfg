config.default_gui_startup_args = { "connect", "ASUSFX" }
config.default_cwd = "/home/theron/.core"

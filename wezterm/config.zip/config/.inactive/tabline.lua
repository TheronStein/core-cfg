local tabline_config = require 'tabline.config'
local tabline_extension = require 'tabline.extension'
local tabline_component = require 'tabline.component'
local tabline_tabs = require 'tabline.tabs'

return {


-- Custom configurations and overrides (edit these as needed)
custom_opts = {
  options = {
    theme = 'Catppuccin Mocha',  -- Or your preferred theme; can be a string or table
    tabs_enabled = true,  -- Enable custom tab formatting
    section_separators = {
      left = wezterm.nerdfonts.pl_left_hard_divider,
      right = wezterm.nerdfonts.pl_right_hard_divider,
    },
    component_separators = {
      left = wezterm.nerdfonts.pl_left_soft_divider,
      right = wezterm.nerdfonts.pl_right_soft_divider,
    },
    tab_separators = {
      left = wezterm.nerdfonts.pl_left_hard_divider,
      right = wezterm.nerdfonts.pl_right_hard_divider,
    },
    icons_enabled = true,  -- Global toggle for icons in components
    -- theme_overrides = { ... }  -- If you need to override theme colors
  },
  sections = {
    -- Customize left status sections (A/B/C)
    tabline_a = { 'mode' },  -- e.g., Shows current mode (normal/copy/search)
    tabline_b = { 'workspace' },
    tabline_c = { ' ' },  -- Spacer

    -- Customize tab content
    tab_active = {
      'index',  -- Tab index
      { 'parent', padding = 0 },  -- Parent dir
      '/',  -- Separator
      { 'cwd', padding = { left = 0, right = 1 } },  -- Current working dir
      { 'zoomed', padding = 0 },  -- Zoom indicator
    },
    tab_inactive = {
      'index',
      { 'process', padding = { left = 0, right = 1 } },  -- Running process
    },

    -- Customize right status sections (X/Y/Z)
    tabline_x = { 'ram', 'cpu' },
    tabline_y = { 'datetime', 'battery' },
    tabline_z = { 'domain' },
  },
  extensions = {
    -- List extensions here (strings for internal, tables for custom)
    -- e.g., 'some_extension',  -- Loads tabline.extensions.some_extension
    -- or { events = { show = 'some-event' }, ... } for custom
  },
}

-- Apply custom options
tabline_config.set(custom_opts)

-- Optionally set or override theme separately (e.g., dynamically)
-- tabline_config.set_theme('NewTheme', { normal_mode = { a = { fg = '#ff0000' } } })

-- Load extensions
tabline_extension.load()


-- Hook into WezTerm events
wezterm.on('update-status', function(window, pane)
  -- Updates left/right status bars (components like mode, workspace, ram, etc.)
  tabline_component.set_status(window)
end)

wezterm.on('format-tab-title', function(tab, tabs, panes, conf, hover, max_width)
  -- Custom tab title formatting (active/inactive tabs with separators)
  local title_elements = tabline_tabs.set_title(tab, hover)
  if title_elements then
    return wezterm.format(title_elements)
  end
  -- Fallback to default if needed
  return tab.active_pane.title
end)

-- Optional: Hook into other events for dynamic updates (e.g., mode changes)
wezterm.on('window-config-reloaded', function(window, pane)
  tabline_component.set_status(window)  -- Refresh on config reload
end)
}
